function [flowrate] = oilflow(min, max)
% OILFLOW    Calculate oil flowrate given power requirements for truck
%   
%   At FakeTrucks Inc. the Thermal Engine System Analysis Team (TESA)
%   developed a correlated function to properly predict an accurate 
%   flowrate for lubrication oil in our engine systems to minimize the
%   number of times the engines will need maintenance.
%
%   For input OILFLOW(min,max) requires estimates for a minimum and maximum
%   power requirement for steady state conditions. Input units are in
%   [hp] and output units are in [L/h]. 
%
%   OILFLOW(min, max)  - Scalar output for recommended flowrate in [L/h]
 

% Input Requirements
if (min < 100)
    error("Minimum power too low for our model")
end

if (max > 700)
    error("Maximum power too large for our model")
end

if (max<min)
    error("Maximum must be larger than minimum.")
end

if (max-min)<=10
    error("Power envolope too small to give accurate estimate")
end

% Experimental Fitting Parameters
k = [ 1.234
      1.44
      1.53
      1.928
      1.231
      3.7655
      1.23
      5.23221
      1.098
      2.35552
      3.0889
      3.14];


% Power domain
P = linspace(min, max);

% First Order ODE modeling system
    function dSdt = f(p,S)
        dSdt = (1/(1+p))^2*[
            k(1)*S(10)*S(1) + S(1)*(330-p)
            k(2)*S(9)*S(2) + S(2)*(430-p)
            k(3)*S(8)*S(3) + S(3)*(330-p)
            k(4)*S(7)*S(4) + S(4)*(330-p)
            k(5)*S(6)*S(5) + S(5)*(100-p)
            k(6)*S(5)*S(6) + S(6)*(250-p)
            k(7)*S(4)*S(7) + S(7)*(100-p)
            k(8)*S(3)*S(8) + S(8)*(100-p)
            k(9)*S(2)*S(9) + S(9)*(320-p)
            k(10)*S(1)*S(10) + S(10)*(20-p)
            ];
    end

% Simulation
S0 = ones(10,1);
[~,S] = ode45(@f,P,S0); % solver

% Emperical Correlation between Elements
power = 0;
for i=1:10
    power = power + k(i+2)*trapz(S(i,:));
end
disp(power)

%flowrate estimation
flowrate = 0.82*power + 20.1433;
fprintf('We recommend to run the pump at %8.3f L/h \n', flowrate)
end

