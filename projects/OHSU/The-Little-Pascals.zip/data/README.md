# `data\`

>   prepared by : Izzie Stevens OHSU (1st year Intern)

Congratulations you’ve managed to download all of the files you’ll need for this project. Below is a description of each data file so you don’t have to waste time trying to figure out what each column is or how to interpret it. 

## `pipes.csv`

This is main file for all the piping dimensional and material data we collected after our massive city survey to spec out this project. There are 5 columns. Each row corresponds to a specific section of municipal piping section. There is an index column on the left, you’ll find this helpful if you wish to `pandas` to perform any sort of searching in a `jupyter` notebook. Ignore it if you wanna stay in `.xlsx`.

1.   `Length [ft]` This is the length of piping section measured in feet.
2.  `Diameter [ft]` This is the diameter of a piping section. There are two possibilities for an entry in this column
    -   **Single Value** : `Diameter [ft] = 3` This means the pipe is ***circular***  so this number is simply the diameter of the pipe.
    -   **Double Value** : `Diameter [ft] = (0.5,0.7)` This means the piping section is ***rectangular***. The first element is the height while the second is the width.  
3.  `Material` : This is the recorded material of the pipe section
4.  `Components` : These are the minor loss components recorded along a section of pipe of a given length and diameter. If an entry is `[]` then this means there are no piping components along that section. We never saw more than **5** components along a given pipe section. 
5.  `Reservoir` : This is the specific reservoir the associated to a given piping section. They should be in order and only three options.

*We don’t know how high up each reservoir is away from our building*, but your boss said you could figure that out pretty easily using the internet.

## `reservoir.csv`

This is a small table of the associated cost to install and maintain our emergency water supply to a given reservoir. There is a bare minimum `Installation Cost $  `cost along with two associated yearly fees given which facility we go with. 



## `invoices.csv`

This is a larger collection of invoices out hospital spends for water in a given 30 day billing cycle. The records go back to 2016 up to our most current. You’re boss asked for us to collect this data for you to get an accurate estimate on our water consumption over a year. I really would only focus on the `Total Charges $` column if I were you. However we usually spend more during the summer months than the winter this is why we usually get a `Surchage Tax $` around that time. The `Rate $` the city charges us for water keeps increasing as well.



