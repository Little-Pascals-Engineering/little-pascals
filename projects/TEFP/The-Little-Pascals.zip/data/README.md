# `data\`  

>   prepared by Geordi La Forge (Chief of Engine Quality and Reliability Directorate  @ Fake Trucks Inc.)

Hello after reading the email on this new design project I went ahead and collected all the important data into a zip for you. There are three `.json` files I’ve included. If you don’t know what a `.json` file is I wouldn’t worry about it, it’s just another data format similar to `.csv` except it is much more readable to the human eye. You can read and import them easily in python using

```python
import json
with open(filename, 'r') as file:
    data = json.load(file)
    
# display json data in formatted string
print(json.dumps(parsed, indent=4, sort_keys=True))
```

Now `data` will be a python [dictionary](https://www.w3schools.com/python/python_dictionaries.asp) which will encode all the properties of the `model`, `system`, or `filters` our company uses. Other programming languages such as [MATLAB](https://www.mathworks.com/help/matlab/ref/jsondecode.html) can also understand `.json` files.

You could also just read the raw text if you wanted by opening it in notepad, I guess. Then you could manually convert all the data in the files into a spread sheet if you wanted…sounds like pulling teeth. 

## `windtunnel\`

Our interns created a massive set of data for three design options for a new cab front.

1.  `modelA.csv ` : Drag force measurement for model A varying temperature and wind speed.
2.  `modelB.csv` : Drag force measurement for model B varying temperature and wind speed.
3.  `modelC.csv` : Drag force measurement for model C varying temperature and wind speed.

In each spread sheet there are 3 columns. 

-   `Windspeed [mph]` : Wind speed in the tunnel in units of mile per hour. This is model of the truck driving at this speed at steady state. 
-   `Temperature [F]` : This is the temperature of the wind tunnel for a given experiment. Our trucks drive is many conditions so we vary this to get a better estimate on the air densities they encounter. 
-   `Drag Force [lbf]` : The measured drag force on a given model in units of pounds force. **WARNING** since this is *pounds force* you have to convert to *pounds mass* in relevant calculations involving density.



### `models.json` 

This is `json` file with the dimension of all three models. The ***front facing area*** of a given model is calculated to $A = wh$. The length $l$ is included if you wanted to do some skin friction analysis modeling the sides of the truck as flat plates. That would be a waste of time in my opinion for a first order estimate.

## `pumps\`

We have attached the actual pump performance data for the three pumps we get great deals on at our company FakeTrucks Inc. The data is quality and they even provide the efficiency rating on each pump. We buy from over seas to sorry about the different unit systems in the data. You’re an engineer, you can figure it out…

1.  `PAI-DT466.csv ` : Pump performance curve data
2.  `CUMINS-M11.csv` : Pump performance curve data
3.  `VOLVO-D13.csv` : Pump performance curve data

Each pump performance data sheet has three columns in it with all the relevant data you need to come up with pump curve fit. 

-   `flowrate [L/h]` : Inlet flowrate given in liters per hour. 
-   `pressure drop [kPa]` : The pressure drop across the pump in kilo-Pascals
-   `efficiency [%]` : The pump efficiency at a given flowrate given in percentage. **REMARK : ** *Efficiency data is a messy business so you can either eyeball a rough $Q_{BEP}$ or curve fit for more accurate value.*  

This data should help you determine the actual change in head $h_a$ for the pumps also known as the **Pump Performance Curves System Curve  $h_a(Q)$** and **Efficiency Curves  $\eta(Q)$** for each pump so you can down select and make engineering decisions.


### `system.json` 

There are two flow systems we’re sizing pumps for. There is the `Delivery` system which gets the oil from the well to the engine components. Then there is the `Filter` system. This system will involve a heavy loss due to the filter. We summarized each system by doing a book keeping of all the pipe section lengths and components. *Both systems have a constant diameter*. 

This data will help you *fully* define the **System Curve $h_s(Q)$** for the `Delivery` system and *partially* for the `Filter`. The loss associated to a given filter is defined in `filters.json`. 

### `filters.json`

There are a couple of filters that we use for our projects. They are all summarized here in a `.json` file. All you’ll probably really care about is the loss coefficient `K`. Some of these filters are really expensive though so when it comes to installing them on an entire fleet of trucks that certainly could add up. The `K` value should heavily influence the operating point when selecting this pump. 

This data will let you finish determining the **System Curve $h_s(Q)$** for the `Filter` system defined in `systems.json` 

### `oilflow.m` 

This is a `MATLAB` function that a separate team developed a couple years ago and it has been paying off. This function should only be considered when you’re sizing the `Delievery` system. They preformed some advanced modeling techniques and machine learning to determine some weights for a large nonlinear system of ODEs that govern the reliability of the main engineer components given our enormous data set involving repairs on our vehicles.

We usually like to find a minimum and maximum power requirement via drag force calculations and other power calculations for the vehicle and then use this function to identify an *optimal reliability flowrate* $Q_R$ for the oil. 

As always the operating point is a separate beast that is determined by the intersection of the **Pump Performance Curve** and **System Curve**. *System resistance* $K(\text{geometry, fluid properties})$ governs where the operating point is, `oilflow.m` governs where an optimal reliability flow is given a power envelope $Q_{R}(\mathbb{P}_{min}, \mathbb{P}_{max})$, and $Q_{BEP}$ is set by the pump you choose.

**Here at Fake Truck Inc. we like to get our operating point $h_a(Q_{op}, K) = h_s(Q_{op}, K)$, best efficiency point $Q_{BEP}$, and this point $Q_{R}(\mathcal{P}_{min}, \mathcal{P}_{max})$ pretty close together!**

 Good luck! Tell me how it goes in the end